Follow this steps :

1. pkg update

2. pkg upgrade

3. pkg install php

3. pkg install curl

4. pkg install git

5. git clone https://github.com/vey251/gjk

6. cd gjk

7. php woyy.php
